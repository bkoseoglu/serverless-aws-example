**To change the default branch for a repository**

This example changes the default branch for an AWS CodeCommit repository. This command produces output only if there are errors.

Command::

  aws codecommit update-default-branch --repository-name MyDemoRepo --default-branch-name MyNewBranch

Output::

  None.